Compilation:
- Prerequisite: Internet connection
- Command:
-- Windows: gradlew.bat build
-- Linux: ./gradlew build

Usage:
- Prerequisite: Java 1.8
- Command: java -jar ./build/libs/PortfolioValuator-1.0.0.jar -c [inputFile]

Input:
Sample input file portfolio.csv is provided. It contains three columns: 
- Ticker: the ticker of assert (Please refer to supported tickers in the systems in the "Note" section for the detail)
- Shares/Contracts: number of shares/contracts held in the position
- Type: specify it is "Stock" or "Option"

Output:
To print out the latest NAV of the whole portfolio and market value for all positions, input 'p' and press enter in the console. It will print out to file "portfolioSummary.txt". Sample output file is included.

Note:
To illustrate the capability of calculating the NAV for portfolio with stock and option, following tickers are supported:
- Stock:
-- 0001.HK
-- 0002.HK
-- 0003.HK
- Option:
-- 0001.HK.Call: Call option with maturity 1 year, strike 80, underlying stock: 0001.HK
-- 0002.HK.Put: Put option with maturity 2 year, strike 78, underlying stock: 0002.HK