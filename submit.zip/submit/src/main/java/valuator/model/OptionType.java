package main.java.valuator.model;

/**
 * Created by williamxuxianglin on 28/12/16.
 */
public enum OptionType {
    CALL, PUT
}
